class DND {
    public void findExit() {
        // Implementiere deine Strategie hier

        // Aufrufbeispiele:
        int n = grader.numOfDoors();
        String notiz = grader.readNote();
        grader.takeNote("Hello World");
        grader.takeDoor(1);
    }
}
