def find_exit(num_of_doors, read_note, take_note, take_door):
    # Die Funktionien werde in Python hier als Parameter übergeben
	
    # Implementiere deine Strategie hier

	# Aufrufbeispiele:
	n = num_of_doors()
	notiz = read_note()
	take_note("Hello World")
	take_door(1)
