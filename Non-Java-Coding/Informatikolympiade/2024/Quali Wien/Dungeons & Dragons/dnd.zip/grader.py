import sys

sys.setrecursionlimit(2000)

try:
    from dnd import find_exit
except ImportError:
    from .dnd import find_exit


MAX_N = 1005
MAX_NOTE = 42
MAX_STEP = 4000000


n, m = map(int, input().split())
adjl = [[] for _ in range(n+1)]
for _ in range(m):
    a, b = map(int, input().split())
    adjl[a].append((b,len(adjl[b])+1))
    adjl[b].append((a,len(adjl[a])))
num_dragons = int(input())

dragons = [False for _ in range(n+1)]
for _ in range(num_dragons):
    a = int(input())
    dragons[a] = True

note = [""] * n

pos = 1
steps = 0

def raise_error(e):
    print(e, file=sys.stderr)
    sys.exit(1)

def numOfDoors():
    return len(adjl[pos])

class DeathException(Exception):
    pass

def takeDoor(k):
    global pos, steps
    if k <= 0 or k > len(adjl[pos]):
        raise_error("Diese Tuer gibt es nicht")
    steps += 1
    if steps > MAX_STEP:
        raise_error("Zu viele Schritte")
    e = adjl[pos][k - 1]
    print("Von", pos, "zu", e[0])
    pos = e[0]
    if pos == n:
        print("Du bist entkommen,", steps, "Schritte")
        sys.exit(0)
    if dragons[pos]:
        print("Tod")
        raise DeathException()
    print("Bei", pos)
    return e[1]


def takeNote(s):
    global note
    s = str(s)
    if len(s) > MAX_NOTE:
        raise_error("Notiz zu lang")
    note[pos] = s


def readNote():
    return note[pos]



while True:
    try:        
        pos = 1
        print("Bei 1")
        find_exit(numOfDoors, readNote, takeNote, takeDoor)
        raise_error("Ausgang nicht gefunden")
    except DeathException:
        pass
