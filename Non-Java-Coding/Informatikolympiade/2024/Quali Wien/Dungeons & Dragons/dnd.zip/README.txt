Dieser Ordner enthält den Grader zum Testen sowie die Dateien die du für deine Abgabe implementieren sollst.

Falls du C++ verwendest:
 - Kopiere dnd.h, dnd.cpp und grader.cpp in dein C++ Projekt.
 - Implementiere die Methode `findExit()` in dnd.cpp. Deine gesamte Implementierung für die Aufgabe
   sollte sich dabei in `dnd.cpp` befinden. Lade für die Abgabe am Server die Datei `dnd.cpp` hoch.

Falls du Java verwendest:
 - Kopiere grader.java und DND.java in dein Java Projekt.
 - Implementiere die Methode `findExit()` in DND.java. Deine gesamte Implementierung für die Aufgabe
   sollte sich dabei in `DND.java` befinden. Lade für die Abgabe am Server die Datei `DND.java` hoch.

1.in und 2.in sind die Beispiel Testcases aus der Angabe.
