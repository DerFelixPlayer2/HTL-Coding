#pragma once
#include <string>

void findExit();
int numOfDoors();
int takeDoor(int);
void takeNote(std::string);
std::string readNote();
