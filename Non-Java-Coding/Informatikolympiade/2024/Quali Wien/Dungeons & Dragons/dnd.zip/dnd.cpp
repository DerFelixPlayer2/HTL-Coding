#include "dnd.h"

using namespace std;

void findExit() {
	// Implementiere deine Strategie hier

	// Aufrufbeispiele:
	int n = numOfDoors();
	string notiz = readNote();
	takeNote("Hello World");
	takeDoor(1);
}
