Dieser Ordner enthält den Grader zum Testen sowie die Dateien die du für deine Abgabe implementieren sollst.

Falls du C++ verwendest:
 - Kopiere zensur.h, zensur.cpp und grader.cpp in dein C++ Projekt.
 - Implementiere die Methode `findBannedWord()` in zensur.cpp. Deine gesamte Implementierung für die Aufgabe
   sollte sich dabei in `zensur.cpp` befinden. Lade für die Abgabe am Server die Datei `zensur.cpp` hoch.

Falls du Java verwendest:
 - Kopiere grader.java und Zensur.java in dein Java Projekt.
 - Implementiere die Methode `findBannedWord()` in Zensur.java. Deine gesamte Implementierung für die Aufgabe
   sollte sich dabei in `Zensur.java` befinden. Lade für die Abgabe am Server die Datei `Zensur.java` hoch.
