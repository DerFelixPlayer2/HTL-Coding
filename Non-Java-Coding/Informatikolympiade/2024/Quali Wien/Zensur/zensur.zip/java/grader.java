import java.util.Scanner;
import java.io.InputStreamReader;

class grader {
  private static String bannedWord;
  private static int count = 0;
  public static boolean sendMessage(String message) {
    count++;
    if (message.length() > 10000) {
      System.out.println("Nachricht zu lang");
      System.exit(1);
    }
    for (int i = 0; i < message.length(); i++) {
      char c = message.charAt(i);
      if (c < 'a' || c > 'z') {
        System.out.println("Nachricht enhaelt nicht nur a-z");
        System.exit(1);
      }
    }
    return message.contains(bannedWord);
  }

  public static void main(String[] args) {
    Scanner in = new Scanner(new InputStreamReader(System.in));
    bannedWord = in.next();
    String ans = new Zensur().findBannedWord();
    if (bannedWord.equals(ans))
      System.out.printf("Ok, %d Nachrichten\n", count);
    else
      System.out.printf("Falsch, %s %s\n", ans, bannedWord);
  }
}
