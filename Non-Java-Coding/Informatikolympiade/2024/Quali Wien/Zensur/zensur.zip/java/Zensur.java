class Zensur {
    public String findBannedWord() {
        // TODO Implementiere deine Strategie hier

        grader.sendMessage("iamaninnocentpersonwhowouldneveruseanybadwords");
	      return "nope";
    }
}
