
def findBannedWord(sendMessage):
    # TODO: Implement your strategy here

    sendMessage("iamaninnocentpersonwhowouldneveruseanybadwords")
    return "nope"
