
# DIESE DATEI NICHT BEARBEITEN
try:
    from zensur import findBannedWord
except ImportError:
    from .zensur import findBannedWord

bad = ""
cnt = 0

def WA(msg):
    print(msg)
    exit(1)

def sendMessage(m):
    global cnt
    cnt += 1

    if len(m) > 10000:
        WA("Nachricht zu lang")

    for c in m:
        if not ('a' <= c <= 'z'):
            WA("Nachricht enhaelt nicht nur a-z")

    for i in range(len(m) - 3):
        if bad == m[i:i+len(bad)]:
            return True

    return False

if __name__ == "__main__":
    bad = input()
    ans = findBannedWord(sendMessage)
    if bad == ans:
        print(f"Ok, {cnt} Nachrichten")
    else:
        print(f"Falsch, {ans} {bad}")
    