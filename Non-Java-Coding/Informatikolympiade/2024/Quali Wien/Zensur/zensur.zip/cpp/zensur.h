#pragma once
#include <string>

std::string findBannedWord();
bool sendMessage(const std::string&);
