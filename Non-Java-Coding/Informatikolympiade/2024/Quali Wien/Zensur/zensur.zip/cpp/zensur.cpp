#include "zensur.h"

std::string findBannedWord()
{
	// TODO Implementiere deine Strategie hier

	sendMessage("iamaninnocentpersonwhowouldneveruseanybadwords");
	return "nope";
}
