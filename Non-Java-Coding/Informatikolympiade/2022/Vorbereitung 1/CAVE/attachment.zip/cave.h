#ifndef __CAVE_H__
#define __CAVE_H__

#ifdef __cplusplus
extern "C" {
#endif

int tryCombination(int S[]);
void answer(int S[], int D[]);
void exploreCave(int N);

#ifdef __cplusplus
}
#endif

#endif /* __CAVE_H__ */
