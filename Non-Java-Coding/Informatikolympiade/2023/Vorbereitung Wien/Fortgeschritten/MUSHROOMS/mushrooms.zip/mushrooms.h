#include <vector>

int count_mushrooms(int n);

int use_machine(std::vector<int> x);

