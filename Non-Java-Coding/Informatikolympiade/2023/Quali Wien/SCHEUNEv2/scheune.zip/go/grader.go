package main

import "fmt"

type Point struct {
	r, c interface{}
}

func main() {
	var n,k int;
	fmt.Scanf("%d %d", &n,&k)
	var trees = make([]Point, k); 
	
	for i := 0; i < k; i++ {
		fmt.Scanf("%d %d", &trees[i].r, &trees[i].c);
	}

	res := solve(n, trees);
	fmt.Println(res);
}
