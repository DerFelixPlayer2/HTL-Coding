package main

func solve(n int, s []Point) int {
	k := len(s);
	firstTreeR := s[0].r;
	firstTreeC := s[0].c;

	// TODO: deine Implementierung

	return 42;
}
