# DIESE DATEI NICHT BEARBEITEN
try:
    from scheune import solve
except ImportError:
    from .scheune import solve

from dataclasses import dataclass

@dataclass(frozen=True)
class Point:
    r: int
    c: int

n, k = map(int, input().split())
trees = []
for _ in range(k):
    r, c = map(int, input().split())
    trees.append(Point(r, c))
print(solve(n, trees))
