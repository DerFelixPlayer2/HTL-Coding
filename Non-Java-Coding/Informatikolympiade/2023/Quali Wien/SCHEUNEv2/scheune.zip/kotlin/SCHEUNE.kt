fun solve(n: Int, trees: Array<Point>): Int {
    val k = s.size
    int firstTreeR = trees[0].r;
    int firstTreeC = trees[0].c;

    // TODO: deine Implementierung

    return 42;
}
