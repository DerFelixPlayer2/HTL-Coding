// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner
import java.io.BufferedReader
import java.io.InputStreamReader
import scheune.*

data class Point(val r: Int, val c: Int)

fun main() {
    val scanner = Scanner(BufferedReader(InputStreamReader(System.`in`)))
    val n = scanner.nextInt()
    val k = scanner.nextInt()
    val trees = Array(k) { Point(0,0) }
    for (i in 0 until n) {
        trees[i].r = scanner.nextInt()
        trees[i].c = scanner.nextInt()
    }
    val res = solve(n, trees)
    println(res)
}
