export function solve(n, trees) {
    const k = trees.length;
    const firstTreeR = trees[0].r;
    const firstTreeC = trees[0].c;

    // TODO: deine Implementierung

    return 42;
}
