// DIESE DATEI NICHT BEARBEITEN
mod scheune;
use std::io::{self, BufRead};

pub struct Point {
    r: i32,
    c: i32,
}

fn main() {
    let stdin = io::stdin();
    let mut iterator = stdin.lock().lines();
    let line = iterator.next().unwrap().unwrap();
    let parts = line.split_whitespace().collect::<Vec<_>>();
    let n = parts[0].parse::<usize>().unwrap();
    let k = parts[1].parse::<usize>().unwrap();
    let trees = (0..k)
        .map(|_| {
            let line = iterator.next().unwrap().unwrap();
            let parts = line.split_whitespace().collect::<Vec<_>>();
            let r = parts[0].parse::<i32>().unwrap();
            let c = parts[0].parse::<i32>().unwrap();
            Point { r: r, c: c }
        })
        .collect::<Vec<_>>();
    let result = scheune::solve(n as i32, &trees);
    println!("{}", result);
}
