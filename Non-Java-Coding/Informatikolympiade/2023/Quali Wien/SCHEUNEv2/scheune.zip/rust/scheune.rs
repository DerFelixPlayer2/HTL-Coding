pub fn solve(n: i32, trees: &[Point]) -> i32 {
    let k = trees.len();
    let first_tree_r = trees[0].r;
    let first_tree_c = trees[0].c;

    // TODO: deine Implementierung

    42
}
