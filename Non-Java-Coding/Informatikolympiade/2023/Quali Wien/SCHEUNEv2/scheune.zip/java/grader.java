
// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class grader {
  public static void main(String[] args) {
    Scanner in = new Scanner(new BufferedReader(new InputStreamReader(System.in)));
    int n = in.nextInt();
    int k = in.nextInt();
    Point trees[] = new Point[k];

    for (int i = 0; i < k; i++) {
      trees[i] = new Point();
      trees[i].r = in.nextInt();
      trees[i].c = in.nextInt();
    }

    int res = SCHEUNE.solve(n, trees);
    System.out.println(res);
  }
}
