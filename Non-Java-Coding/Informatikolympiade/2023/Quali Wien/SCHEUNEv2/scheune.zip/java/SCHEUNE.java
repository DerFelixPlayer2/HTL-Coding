
class SCHEUNE {
    public static int solve(int n, Point[] trees) {
        int k = trees.length;
        int firstTreeR = trees[0].r;
        int firstTreeC = trees[0].c;

        // TODO: deine Implementierung

        return 42;
    }
}
