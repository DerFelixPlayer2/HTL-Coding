public class Point {
  public int r;
  public int c;
}
