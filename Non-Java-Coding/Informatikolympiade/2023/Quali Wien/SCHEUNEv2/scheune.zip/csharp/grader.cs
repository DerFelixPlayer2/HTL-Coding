using System;
using System.IO;
using static SCHEUNE;

public struct Point 
{
   public int R {get;set;}
   public int C {get;set;}
}

class Grader
{
    public static void Main(string[] args)
    {
        string[] tokens = Console.ReadLine().Split();
        int n = Convert.ToInt32(tokens[0]);
        int k = Convert.ToInt32(tokens[1]);
        Point[] trees = new Point[k];
        for(int i=0;i<k; i++)
        {
            trees[i] = new Point();
            string[] line = Console.ReadLine().Split();
            trees[i].R = Convert.ToInt32(line[0]);
            trees[i].C = Convert.ToInt32(line[1]);
        }

        int res = SCHEUNE.solve(n, trees);
        Console.WriteLine(res);
    }
}
