public class SCHEUNE
{
    public static int solve(int n, Point[] s)
    {
        int k = s.Length;
        int firstTreeR = s[0].R;
        int firstTreeC = s[0].C;

        // TODO: deine Implementierung

        return 42;
    }
}
