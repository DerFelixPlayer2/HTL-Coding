// DIESE DATEI NICHT BEARBEITEN
import * as readline from "readline";
import * as scheune from "./scheune";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

const getLine = (function () {
    const getLineGen = (async function* () {
        for await (const line of rl) {
            yield line;
        }
    })();
    return async () => ((await getLineGen.next()).value);
})();

const main = async () => {
    const line = await getLine();
    const parts = line.split(' ').map(x => parseInt(x));
    const n = parts[0];
    const k = parts[1];
    const trees: {r: number, c: number}[] = [];
    for (let i = 0; i < k; i++) {
        const line = await getLine();
        const parts = line.split(' ').map(x => parseInt(x));
        trees.push({r: parts[0], c: parts[1]});
    }
    const result = scheune.solve(n, trees);
    console.log(result);

    rl.close();
    process.exit(0);
};

main();
