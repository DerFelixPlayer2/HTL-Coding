#include <vector>
#include <utility>

struct Point {
  int r, c;
};

int solve(int n, const std::vector<Point> &trees);
