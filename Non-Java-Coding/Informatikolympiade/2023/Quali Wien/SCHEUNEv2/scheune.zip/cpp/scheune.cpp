#include "scheune.h"

using namespace std;

int solve(int n, const vector<Point> &trees) {
  int k = trees.size();
  int first_tree_r = trees[0].r;
  int first_tree_c = trees[0].c;

  // TODO: deine Implementierung

  return 42;
}
