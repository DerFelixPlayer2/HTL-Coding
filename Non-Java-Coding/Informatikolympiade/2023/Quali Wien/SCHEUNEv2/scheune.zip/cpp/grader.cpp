#include <cstdio>

#include "scheune.h"

using namespace std;

int main() {
  int n, k;
  scanf("%d %d", &n, &k);
  vector<Point> v(k);
  for (auto &x : v) scanf("%d %d", &x.r, &x.c);
  int res = solve(n, v);
  printf("%d\n", res);
  return 0;
}
