let s = readLine()
print(solve(s: s!))
