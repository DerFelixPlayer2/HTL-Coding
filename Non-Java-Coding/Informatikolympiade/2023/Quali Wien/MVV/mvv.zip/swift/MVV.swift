func solve(s: String) -> Character {
    // s hat länge n
    let n = s.count;

    // TODO

    return "R";
}
