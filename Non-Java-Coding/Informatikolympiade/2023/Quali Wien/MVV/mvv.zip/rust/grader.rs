// DIESE DATEI NICHT BEARBEITEN
mod mvv;
use std::io::{self,BufRead};

fn main() {
    let stdin = io::stdin();
    let line = stdin.lock().lines().next().unwrap().unwrap();
    let res = mvv::solve(&line);
    println!("{}", res);
}
