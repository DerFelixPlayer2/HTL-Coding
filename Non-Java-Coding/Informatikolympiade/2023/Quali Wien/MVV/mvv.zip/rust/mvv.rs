pub fn solve(s: &str) -> char {
    return 'R';
}
