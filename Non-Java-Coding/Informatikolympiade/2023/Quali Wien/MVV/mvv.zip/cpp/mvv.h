// DIESE DATEI NICHT BEARBEITEN
#include <string>

char solve(std::string s);
