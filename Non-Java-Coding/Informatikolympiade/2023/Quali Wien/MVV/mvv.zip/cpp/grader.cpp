// DIESE DATEI NICHT BEARBEITEN
#include <iostream>
#include "mvv.h"

using namespace std;

int main() {
  string s;
  cin >> s;
  char res = solve(s);
  cout << res << endl;
  return 0;
}
