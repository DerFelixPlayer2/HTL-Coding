#include "mvv.h"

using namespace std;

char solve(string s) {
  // s hat länge n
  int n = s.size();

  // TODO

  return 'R';
}
