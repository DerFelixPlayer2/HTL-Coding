public class MVV
{
    public static char solve(string s)
    {
        return 'R';
    }
}