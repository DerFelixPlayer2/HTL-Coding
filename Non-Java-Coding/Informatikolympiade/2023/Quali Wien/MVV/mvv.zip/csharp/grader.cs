using System;
using System.IO;
using static MVV;

class Grader
{
    public static void Main(string[] args)
    {
        string input = Console.ReadLine();
        char res = MVV.solve(input);
        Console.WriteLine(res);
    }
}
