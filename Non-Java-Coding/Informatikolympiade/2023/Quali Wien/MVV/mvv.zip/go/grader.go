package main

import "fmt"

func main() {
	var input string
	fmt.Scanln(&input)
	res := solve(input)
	fmt.Println(string(res))
}
