package main

func solve(s string) byte {
	return 'R'
}
