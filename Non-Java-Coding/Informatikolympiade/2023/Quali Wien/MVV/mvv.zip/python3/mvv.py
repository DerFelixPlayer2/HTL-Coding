
def solve(s: str) -> str:
    return "R"
