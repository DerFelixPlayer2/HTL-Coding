# DIESE DATEI NICHT BEARBEITEN
try:
    from mvv import solve
except ImportError:
    from .mvv import solve

s = input()
res = solve(s)
assert len(res) == 1
print(res)
