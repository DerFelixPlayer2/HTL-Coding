
export function solve(s: string): string {
  return 'R';
}
