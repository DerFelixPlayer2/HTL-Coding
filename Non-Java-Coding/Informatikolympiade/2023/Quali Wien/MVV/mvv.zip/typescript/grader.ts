// DIESE DATEI NICHT BEARBEITEN
import * as readline from "readline";
import { solve } from "./mvv";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

rl.on('line', (line) => {
  const res = solve(line);
  console.log(res);
  rl.close();
  process.exit(0);
});
