// DIESE DATEI NICHT BEARBEITEN
const readline = require('readline');
const mvv = require('./mvv');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

rl.on('line', (line) => {
  const res = mvv.solve(line);
  console.log(res);
  rl.close();
  process.exit(0);
});
