
module.exports.solve = function solve(s) {
  return 'R';
}
