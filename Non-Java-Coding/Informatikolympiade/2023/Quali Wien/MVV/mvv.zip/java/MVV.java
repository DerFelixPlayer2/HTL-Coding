class MVV {
    public static char solve(String s) {
        return 'R';
    }
}
