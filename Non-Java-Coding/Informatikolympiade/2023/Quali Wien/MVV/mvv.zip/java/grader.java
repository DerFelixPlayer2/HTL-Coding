// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class grader {
  public static void main(String[] args) {
    Scanner in = new Scanner(new BufferedReader(new InputStreamReader(System.in)));
    String input = in.next();
    char res = MVV.solve(input);
    System.out.println(res);
  }
};
