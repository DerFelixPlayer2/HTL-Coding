package mvv;

fun solve(s: String): Char {
    return 'R';
}
