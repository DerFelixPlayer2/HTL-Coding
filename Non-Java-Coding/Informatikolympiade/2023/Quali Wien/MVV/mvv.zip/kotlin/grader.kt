// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner
import java.io.BufferedReader
import java.io.InputStreamReader
import mvv.solve

fun main() {
    val scanner = Scanner(BufferedReader(InputStreamReader(System.`in`)))
    val input = scanner.next()
    val res = solve(input)
    println(res);
}
