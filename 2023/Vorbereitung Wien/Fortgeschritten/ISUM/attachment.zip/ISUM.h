
void init(int N);
void update(int p, int q, int v);
long long query(int p, int q);
