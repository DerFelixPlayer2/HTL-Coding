#include "shopping.h"

using namespace std;

void alice(vector<int> p) {
  bool b = receive();
  send(!b);
}
int bob(int n, int l, int r) {
  send(true);
  return receive() ? 42 : 1337;
}
