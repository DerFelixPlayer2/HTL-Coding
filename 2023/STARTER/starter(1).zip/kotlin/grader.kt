// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner
import java.io.BufferedReader
import java.io.InputStreamReader
import starter.*

fun main() {
    val scanner = Scanner(BufferedReader(InputStreamReader(System.`in`)))
    val subtask = scanner.nextInt()
    if (subtask == 1) {
        val a = scanner.nextInt()
        val b = scanner.nextInt()
        println(subtask1(a, b))
    } else if (subtask == 2) {
        val n = scanner.nextInt()
        println(subtask2(n))
    } else if (subtask == 3) {
        val n = scanner.nextInt()
        val q = scanner.nextInt()
        val v = IntArray(n)
        for (i in 0 until n) {
            v[i] = scanner.nextInt()
        }
        for (i in 0 until q) {
            val x = scanner.nextInt()
            println(subtask3(v, x))
        }
    } else {
        println("invalid subtask $subtask")
        System.exit(1)
    }
}
