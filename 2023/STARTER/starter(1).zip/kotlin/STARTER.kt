package starter;

fun subtask1(a: Int, b: Int): Int {
    // hier deine lösung zu teilaufgabe 1
    return 42;
}

fun subtask2(n: Int): Int {
    // hier deine lösung zu teilaufgabe 2
    return 42;
}

fun subtask3(v: IntArray, x: Int): Boolean {
    // hier deine lösung zu teilaufgabe 3
    return true;
}
