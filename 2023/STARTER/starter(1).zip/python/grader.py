# DIESE DATEI NICHT BEARBEITEN
try:
    from starter import subtask1, subtask2, subtask3
except ImportError:
    from .starter import subtask1, subtask2, subtask3

subtask = int(input())
if subtask == 1:
    a, b = map(int, input().split())
    print(subtask1(a, b))
elif subtask == 2:
    n = int(input())
    print(int(subtask2(n)))
elif subtask == 3:
    n, q = map(int, input().split())
    v = list(map(int, input().split()))
    qx = list(map(int, input().split()))
    for x in qx:
        print("true" if subtask3(v, x) else "false")
else:
    print("invalid subtask %d" % subtask)
    exit(1)
