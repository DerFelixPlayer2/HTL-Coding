def subtask1(a, b):
    # hier deine lösung zu teilaufgabe 1
    return 42


def subtask2(n):
    # hier deine lösung zu teilaufgabe 2
    return 42


def subtask3(v, x):
    # hier deine lösung zu teilaufgabe 3
    return True
