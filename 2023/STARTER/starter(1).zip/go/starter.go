package main

func subtask1(a int, b int) int {
	// hier deine lösung zu teilaufgabe 1
	return 42;
}

func subtask2(n int) int {
	// hier deine lösung zu teilaufgabe 2
	return 42;
}

func subtask3(v []int, x int) bool {
	// hier deine lösung zu teilaufgabe 3
	return true;
}
