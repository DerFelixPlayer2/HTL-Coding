package main

import (
	"fmt"
	"os"
)

func main() {
	var subtask int
	fmt.Scanln(&subtask)
	if subtask == 1 {
		var a, b int
		fmt.Scanln(&a, &b)
		fmt.Println(subtask1(a, b))
	} else if subtask == 2 {
		var n int
		fmt.Scanln(&n)
		fmt.Println(subtask2(n))
	} else if subtask == 3 {
		var n, q int
		fmt.Scanln(&n, &q)
		v := make([]int, n)
		for i := 0; i < n; i++ {
			fmt.Scan(&v[i])
		}
		for i := 0; i < q; i++ {
			var x int
			fmt.Scan(&x)
			fmt.Println(subtask3(v, x))
		}
	} else {
		fmt.Printf("invalid subtask %d", subtask)
		os.Exit(1)
	}
}
