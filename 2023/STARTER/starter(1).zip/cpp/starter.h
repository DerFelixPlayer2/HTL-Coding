#pragma once
#include <vector>

int subtask1(int a, int b);

int subtask2(int n);

bool subtask3(std::vector<int> &v, int x);
