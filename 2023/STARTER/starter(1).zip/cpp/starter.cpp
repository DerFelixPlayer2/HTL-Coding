#include "starter.h"

int subtask1(int a, int b) {
  // hier deine lösung zu teilaufgabe 1
  return 42;
}

int subtask2(int n) {
  // hier deine lösung zu teilaufgabe 2
  return 42;
}

bool subtask3(std::vector<int> &v, int x) {
  // hier deine lösung zu teilaufgabe 3
  return true;
}
