public class STARTER
{
    public static int subtask1(int a, int b)
    {
        // hier deine lösung zu teilaufgabe 1
	    return 42;
    }
    public static int subtask2(int n)
    {
        // hier deine lösung zu teilaufgabe 2
	    return 42;
    }
    public static bool subtask3(int[] a, int b)
    {
        // hier deine lösung zu teilaufgabe 3
	    return true;
    }
}
