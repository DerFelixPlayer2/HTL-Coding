using System;
using System.IO;
using static STARTER;

class Grader
{
    public static void Main(string[] args)
    {
        int subtask = Convert.ToInt32(Console.ReadLine());
        if (subtask == 1)
        {
            string[] tokens = Console.ReadLine().Split();
            int a = Convert.ToInt32(tokens[0]);
            int b = Convert.ToInt32(tokens[1]);
            Console.WriteLine(STARTER.subtask1(a, b));
        }
        else if (subtask == 2)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(STARTER.subtask2(n));
        }
        else if (subtask == 3)
        {
            string[] tokens = Console.ReadLine().Split();
            int n = Convert.ToInt32(tokens[0]);
            int q = Convert.ToInt32(tokens[1]);
            tokens = Console.ReadLine().Split();
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
            {
                a[i] = Convert.ToInt32(tokens[i]);
            }
            tokens = Console.ReadLine().Split();
            for (int i = 0; i < q; i++)
            {
                int x = Convert.ToInt32(tokens[i]);
                Console.WriteLine(STARTER.subtask3(a, x) ? "true" : "false");
            }
        }
        else
        {
            throw new Exception("Invalid subtask");
        }
    }
}
