
export function subtask1(a: number, b: number): number {
    // hier deine lösung zu teilaufgabe 1
    return 42;
}

export function subtask2(n: number): number {
    // hier deine lösung zu teilaufgabe 2
    return 42;
}

export function subtask3(v: number[], x: number): boolean {
    // hier deine lösung zu teilaufgabe 3
    return true;
}
