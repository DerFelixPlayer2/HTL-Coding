// DIESE DATEI NICHT BEARBEITEN
const readline = require('readline');
const starter = require('./starter');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

const getLine = (function () {
    const getLineGen = (async function* () {
        for await (const line of rl) {
            yield line;
        }
    })();
    return async () => ((await getLineGen.next()).value);
})();

const main = async () => {
    const subtask = parseInt(await getLine());
    if (subtask === 1) {
        const [a, b] = (await getLine()).split(' ').map(x => parseInt(x));
        console.log(starter.subtask1(a, b));
    } else if (subtask === 2) {
        const n = parseInt(await getLine());
        console.log(starter.subtask2(n));
    } else if (subtask === 3) {
        const [n, q] = (await getLine()).split(' ').map(x => parseInt(x));
        const v = (await getLine()).split(' ').map(x => parseInt(x));
        const qx = (await getLine()).split(' ').map(x => parseInt(x));
        for (let x of qx) {
            console.log(starter.subtask3(v, x));
        }
    } else {
        console.log(`invalid subtask ${subtask}`);
        process.exit(1);
    }

    rl.close();
    process.exit(0);
};

main();
