export function subtask1(a, b) {
    // hier deine lösung zu teilaufgabe 1
    return 42;
}

export function subtask2(n) {
    // hier deine lösung zu teilaufgabe 2
    return 42;
}

export function subtask3(v, x) {
    // hier deine lösung zu teilaufgabe 3
    return true;
}
