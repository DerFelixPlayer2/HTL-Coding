// DIESE DATEI NICHT BEARBEITEN
mod starter;
use std::io::{self,BufRead};

fn main() {
    let stdin = io::stdin();
    let mut iterator = stdin.lock().lines();
    let subtask = iterator.next().unwrap().unwrap().parse::<i32>().unwrap();
    if subtask == 1 {
        let line = iterator.next().unwrap().unwrap();
        let mut iter = line.split_whitespace();
        let a = iter.next().unwrap().parse::<i32>().unwrap();
        let b = iter.next().unwrap().parse::<i32>().unwrap();
        println!("{}", starter::subtask1(a, b));
    } else if subtask == 2 {
        let n = iterator.next().unwrap().unwrap().parse::<i32>().unwrap();
        println!("{}", starter::subtask2(n));
    } else if subtask == 3 {
        let line = iterator.next().unwrap().unwrap();
        let mut iter = line.split_whitespace();
        let _n = iter.next().unwrap().parse::<i32>().unwrap();
        let _q = iter.next().unwrap().parse::<i32>().unwrap();
        let v = iterator.next().unwrap().unwrap().split_whitespace().map(|x| x.parse::<i32>().unwrap()).collect::<Vec<_>>();
        let qx = iterator.next().unwrap().unwrap().split_whitespace().map(|x| x.parse::<i32>().unwrap()).collect::<Vec<_>>();
        for x in qx {
            println!("{}", starter::subtask3(&v, x));
        }
    } else {
        panic!("invalid subtask {}", subtask);
    }
}

