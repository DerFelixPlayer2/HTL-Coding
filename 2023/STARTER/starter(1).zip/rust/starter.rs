pub fn subtask1(a: i32, b: i32) -> i32 {
    // hier deine lösung zu teilaufgabe 1
    42
}

pub fn subtask2(n: i32) -> i32 {
    // hier deine lösung zu teilaufgabe 2
    42
}

pub fn subtask3(v: &[i32], x: i32) -> bool {
    // hier deine lösung zu teilaufgabe 3
    true
}
