// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class grader {
  public static void main(String[] args) {
    Scanner in = new Scanner(new BufferedReader(new InputStreamReader(System.in)));
    int subtask = in.nextInt();
    if (subtask == 1) {
      int a = in.nextInt();
      int b = in.nextInt();
      System.out.println(STARTER.subtask1(a, b));
    } else if (subtask == 2) {
      int n = in.nextInt();
      System.out.println(STARTER.subtask2(n));
    } else if (subtask == 3) {
      int n = in.nextInt();
      int q = in.nextInt();
      int[] v = new int[n];
      for (int i = 0; i < n; i++)
        v[i] = in.nextInt();
      for (int i = 0; i < q; i++) {
        int x = in.nextInt();
        System.out.println(STARTER.subtask3(v, x));
      }
    } else {
      System.out.println("invalid subtask " + subtask);
      System.exit(1);
    }
  }
}
