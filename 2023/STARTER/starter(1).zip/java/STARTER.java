class STARTER {
    public static int subtask1(int a, int b) {
        // hier deine loesung zu teilaufgabe 1
        return 42;
    }
    public static int subtask2(int n) {
        // hier deine loesung zu teilaufgabe 2
        return 42;
    }
    public static boolean subtask3(int[] v, int x) {
        // hier deine loesung zu teilaufgabe 3
        return true;
    }
}
