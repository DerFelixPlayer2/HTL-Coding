package main

func blindeKuh(n int) {
	// TODO: Implementieren
	hit(42, 42)
}
