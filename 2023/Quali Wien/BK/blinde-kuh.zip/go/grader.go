package main

import (
	"fmt"
	"os"
)

var n int
var tx int
var ty int
var queries int = 0
var ld int64 = 1 << 62

func dist(x int, y int) int64 {
  return int64(x - tx) * int64(x - tx) + int64(y - ty) * int64(y - ty)
}

func hit(x int, y int) bool {
	if x < 0 || y < 0 || x >= int(n) || y >= int(n) {
    panic("out of bounds queries")
  }
  queries++
  if x == tx && y == ty {
    fmt.Println(queries)
    os.Exit(0)
  }
  d := dist(x, y)
  res := d < ld
  ld = d
  return res
}

func main() {
	fmt.Scanf("%d %d %d", &n, &tx, &ty)
	blindeKuh(n)
	fmt.Fprintln(os.Stderr, "target not found")
	os.Exit(1)
}
