
def blinde_kuh(hit, n: int):
    # Hinweis: In Python wird die hit-funktion als argument übergeben
    hit(42, 42)
