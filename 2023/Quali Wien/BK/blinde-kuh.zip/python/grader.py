# DIESE DATEI NICHT BEARBEITEN
import sys
try:
    from bk import blinde_kuh
except ImportError:
    from .bk import blinde_kuh

last_dist = 1 << 62
queries = 0
n, tx, ty = map(int, input().split())


def dist(x, y):
    return (x-tx)**2 + (y-ty)**2


def hit(x, y):
    global queries, last_dist
    x = int(x)
    y = int(y)
    if x < 0 or y < 0 or x >= n or y >= n:
        print("out of bounds queries")
        sys.exit(1)
    queries += 1
    if x == tx and y == ty:
        print(queries)
        sys.exit(0)
    d = dist(x, y)
    res = d < last_dist
    last_dist = d
    return res
    

blinde_kuh(hit, n)
print("target not found")
sys.exit(1)
