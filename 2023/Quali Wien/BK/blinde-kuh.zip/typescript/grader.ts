// DIESE DATEI NICHT BEARBEITEN
import * as readline from "readline";
import { blindeKuh } from "./bk";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

const getLine = (function () {
    const getLineGen = (async function* () {
        for await (const line of rl) {
            yield line;
        }
    })();
    return async () => ((await getLineGen.next()).value);
})();

let n = 0, tx = 0, ty = 0;
let queries = 0;
let ld = 1 << 62;

function dist(x: number, y: number): number {
    return (x - tx) * (x - tx) + (y - ty) * (y - ty);
}

async function hit(x: number, y: number): Promise<boolean> {
    if (x < 0 || y < 0 || x >= n || y >= n) {
        throw new Error("out of bounds queries");
    }
    queries++;
    if (x === tx && y === ty) {
        console.log(queries);
        process.exit(0);
    }
    const d = dist(x, y);
    const res = d < ld;
    ld = d;
    return res;
}

const main = async () => {
    const line = await getLine();
    const parts = line.split(' ').map(x => parseInt(x));
    n = parts[0];
    tx = parts[1];
    ty = parts[2];

    await blindeKuh(hit, n);
    rl.close();
    console.error("target not found");
    process.exit(1);
};

main();
