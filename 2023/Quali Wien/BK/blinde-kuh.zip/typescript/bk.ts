export async function blindeKuh(
    hit: (x: number, y: number) => Promise<boolean>, 
    n: number
): Promise<void> {
    // TODO: Implementieren
    await hit(42, 42);
}
