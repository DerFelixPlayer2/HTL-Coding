class BK {
    public static void blindeKuh(int n) {
        // TODO: Implementieren
        grader.hit(42, 42);
    }
}
