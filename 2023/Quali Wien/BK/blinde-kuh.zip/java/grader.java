// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class grader {
  private static int n, tx, ty, queries = 0;
  private static long ld = 1L << 62;

  private static long dist(int x, int y) {
	  return (x - tx)*1L*(x - tx) + (y - ty)*1L*(y - ty);
  }
  
  public static boolean hit(int x, int y) {
    if (x < 0 || y < 0 || x >= n || y >= n) {
      throw new IllegalArgumentException("out of bounds queries");
    }
    queries++;
    if (x == tx && y == ty) {
      System.out.println(queries);
      System.exit(0);
    }
    long d = dist(x, y);
    boolean res = d < ld;
    ld = d;
    return res;
  }

  public static void main(String[] args) {
    Scanner in = new Scanner(new BufferedReader(new InputStreamReader(System.in)));
    n = in.nextInt();
    tx = in.nextInt();
    ty = in.nextInt();
    BK.blindeKuh(n);
    System.err.println("target not found");
    System.exit(1);
  }
}
