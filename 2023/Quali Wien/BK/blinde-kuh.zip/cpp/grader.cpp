#include "blinde-kuh.h"
#include <cstdlib>
#include <cmath>
#include <iostream>

static int n, tx, ty, queries;
static long long ld = 1ll << 62;

static long long dist(int x, int y) {
	return (x - tx)*1LL*(x - tx) + (y - ty)*1LL*(y - ty);
}

bool hit(int x, int y) {
	if (x < 0 || y < 0 || x >= n || y >= n) {
		std::cerr << "out of bounds queries\n";
		std::exit(1);
	}
	queries++;
	if (x == tx && y == ty) {
		std::cout << queries << std::endl;
		std::exit(0);
	}
	auto d = dist(x, y);
	bool res = d < ld;
	ld = d;
	return res;
}

int main() {
	std::cin >> n >> tx >> ty;
	blinde_kuh(n);
	std::cerr << "target not found\n";
	return 1;
}
