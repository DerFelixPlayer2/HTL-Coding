#include "blinde-kuh.h"

void blinde_kuh(int n) {
  // TODO: Implementieren
  hit(42, 42);
}
