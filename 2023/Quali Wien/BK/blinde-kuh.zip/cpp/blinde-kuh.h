#pragma once

void blinde_kuh(int n);
bool hit(int x, int y);
