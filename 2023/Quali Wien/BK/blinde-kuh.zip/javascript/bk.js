export async function blindeKuh(hit, n) {
    // TODO: Implementieren
    await hit(42, 42);
}
