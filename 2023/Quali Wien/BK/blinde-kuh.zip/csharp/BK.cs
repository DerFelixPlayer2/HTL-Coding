using static Grader;

public class BK
{
    public static void blindeKuh(int n)
    {
        // TODO: Implementieren
        Grader.hit(42, 42);
    }
}
