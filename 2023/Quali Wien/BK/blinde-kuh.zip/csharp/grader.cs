using System;
using System.IO;
using static BK;

class Grader
{
    private static int n, tx, ty, queries;
    private static long ld = 1L << 62;

    private static long dist(int x, int y) {
	    return (x - tx)*1L*(x - tx) + (y - ty)*1L*(y - ty);
    }

    public static bool hit(int x, int y) {
        if (x < 0 || y < 0 || x >= n || y >= n) {
            throw new ArgumentException("out of bounds queries");
        }
        queries++;
        if (x == tx && y == ty) {
            Console.WriteLine(queries);
            Environment.Exit(0);
        }
        long d = dist(x, y);
        bool res = d < ld;
        ld = d;
        return res;
    }

    public static void Main(string[] args)
    {
        string[] tokens = Console.ReadLine().Split();
        n = Convert.ToInt32(tokens[0]);
        tx = Convert.ToInt32(tokens[1]);
        ty = Convert.ToInt32(tokens[2]);
        BK.blindeKuh(n);
        Console.Error.WriteLine("target not found");
        Environment.Exit(0);
    }
}
