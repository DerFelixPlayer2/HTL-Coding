// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.system.exitProcess
import bk.blindeKuh

private var n = 0
private var tx = 0
private var ty = 0
private var queries = 0
private var ld: Long = 1L shl 62

private fun dist(x: Int, y: Int): Long {
  return (x - tx)*1L*(x - tx) + (y - ty)*1L*(y - ty)
}

public fun hit(x: Int, y: Int): Boolean {
  if (x < 0 || y < 0 || x >= n || y >= n) {
    throw IllegalArgumentException("out of bounds queries")
  }
  queries++
  if (x == tx && y == ty) {
    println(queries)
    exitProcess(0)
  }
  val d = dist(x, y)
  val res = d < ld
  ld = d
  return res
}

fun main() {
    val scanner = Scanner(BufferedReader(InputStreamReader(System.`in`)))
    n = scanner.nextInt()
    tx = scanner.nextInt()
    ty = scanner.nextInt()
    blindeKuh(n)
    System.err.println("target not found")
    exitProcess(1)
}
