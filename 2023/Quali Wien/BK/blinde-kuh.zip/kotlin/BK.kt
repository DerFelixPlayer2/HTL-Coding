package bk
import hit

fun blindeKuh(n: Int): Unit {
    // TODO: Implementieren
    hit(42, 42)
}
