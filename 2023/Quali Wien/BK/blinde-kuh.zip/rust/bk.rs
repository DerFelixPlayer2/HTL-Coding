use hit;

pub fn blinde_kuh(n: i32) {
    // TODO: Implementieren
    hit(42, 42);
}
