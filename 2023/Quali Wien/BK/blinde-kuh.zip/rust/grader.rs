// DIESE DATEI NICHT BEARBEITEN
mod bk;
use std::io::{self, BufRead};
use std::process;

static mut N: i32 = 0;
static mut TX: i32 = 0;
static mut TY: i32 = 0;
static mut QUERIES: i32 = 0;
static mut LD: i64 = 1i64 << 62;

fn dist(x: i32, y: i32) -> i64 {
    unsafe { 
        (((x - TX) * (x - TX)) as i64) 
        + 
        (((y - TY) * (y - TY)) as i64)
    }
}

fn hit(x: i32, y: i32) -> bool {
    let mut n: i32 = 0;
    let mut tx: i32 = 0;
    let mut ty: i32 = 0;
    unsafe {
        n = N;
        tx = TX;
        ty = TY;
    }
    if x < 0 || y < 0 || x >= n || y >= n {
        eprintln!("out of bounds queries");
        process::exit(1);
    }
    let mut q: i32 = 0;
    unsafe {
        QUERIES += 1;
        q = QUERIES;
    }
    if x == tx && y == ty {
        println!("{}", q);
        process::exit(0);
    }
    let d = dist(x, y);
    let mut ld: i64 = 0;
    unsafe {
        ld = LD;
    }
    let res = d < ld;
    unsafe {
        LD = d;
    }
    res
}

fn main() {
    let stdin = io::stdin();
    let line = stdin.lock().lines().next().unwrap().unwrap();
    let mut iter = line.split_whitespace();
    let n = iter.next().unwrap().parse::<i32>().unwrap();
    let tx = iter.next().unwrap().parse::<i32>().unwrap();
    let ty = iter.next().unwrap().parse::<i32>().unwrap();
    unsafe {
        N = n;
        TX = tx;
        TY = ty;
    }

    bk::blinde_kuh(n);
    eprintln!("target not found");
    process::exit(1);
}
