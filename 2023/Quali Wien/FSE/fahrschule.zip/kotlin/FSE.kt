package fse;

fun solve(s: Array<String>): Int {
    val n = s.size
    val m = s[0].length
    
    // TODO implement solution
    
    return 42
}
