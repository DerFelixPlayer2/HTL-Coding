// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner
import java.io.BufferedReader
import java.io.InputStreamReader
import fse.solve

fun main() {
    val scanner = Scanner(BufferedReader(InputStreamReader(System.`in`)))
    val n = scanner.nextInt()
    val m = scanner.nextInt()
    val field = Array(n) { "" }
    for (i in 0 until n) {
        field[i] = scanner.nextLine()
    }
    val res = solve(field)
    println(res)
}
