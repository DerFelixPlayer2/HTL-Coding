
// DIESE DATEI NICHT BEARBEITEN
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class grader {
  public static void main(String[] args) {
    Scanner in = new Scanner(new BufferedReader(new InputStreamReader(System.in)));
    int n = in.nextInt();
    int m = in.nextInt();
    String feld[] = new String[n];

    for (int i = 0; i < n; i++) {
      feld[i] = in.nextLine();
    }

    int res = FSE.solve(feld);
    System.out.println(res);
  }
};
