
class FSE {
    public static int solve(String s[]) {
        int n = s.length;
        int m = s[0].length();
        
        // TODO implement solution
        
        return 42;
    }
}
