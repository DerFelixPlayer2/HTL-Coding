public class FSE
{
    public static int solve(string[] s)
    {
        return 42;
    }
}