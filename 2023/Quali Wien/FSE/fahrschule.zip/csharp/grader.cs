using System;
using System.IO;
using static FSE;

class Grader
{
    public static void Main(string[] args)
    {
        string[] tokens = Console.ReadLine().Split();
        int n = Convert.ToInt32(tokens[0]);
        int m = Convert.ToInt32(tokens[1]);
        string[] field = new string[n];
        for(int i=0;i<n; i++)
        {
            field[i]=Console.ReadLine();
        }

        int res = FSE.solve(field);
        Console.WriteLine(res);
    }
}
