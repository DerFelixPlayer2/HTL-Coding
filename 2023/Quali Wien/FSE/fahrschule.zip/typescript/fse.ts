export function solve(field: string[]): number {
    const n = field.length;
    const m = field[0].length;
    // TODO: add solution here
    return 42;
}
