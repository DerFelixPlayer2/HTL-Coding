// DIESE DATEI NICHT BEARBEITEN
mod fse;
use std::io::{self, BufRead};

fn main() {
    let stdin = io::stdin();
    let mut iterator = stdin.lock().lines();
    let line = iterator.next().unwrap().unwrap();
    let parts = line.split_whitespace().collect::<Vec<_>>();
    let n = parts[0].parse::<usize>().unwrap();
    let m = parts[1].parse::<usize>().unwrap();
    let field = (0..n)
        .map(|_| iterator.next().unwrap().unwrap())
        .collect::<Vec<_>>();
    let result = fse::solve(&field);
    println!("{}", result);
}
