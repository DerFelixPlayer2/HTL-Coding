pub fn solve(field: &[String]) -> i32 {
    let n = field.len();
    let m = field[0].len();
    // TODO: add solution here
    42
}
