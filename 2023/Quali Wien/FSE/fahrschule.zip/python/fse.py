def solve(field):
    n = len(field)
    m = len(field[0])
    # TODO: add solution here
    return 42
