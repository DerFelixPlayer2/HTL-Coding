# DIESE DATEI NICHT BEARBEITEN
try:
    from fse import solve
except ImportError:
    from .fse import solve

n, m = map(int, input().split())
field = [input() for _ in range(n)]
print(solve(field))
