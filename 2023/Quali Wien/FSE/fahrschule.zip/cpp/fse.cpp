#include "fse.h"

using namespace std;

int solve(vector<string> lines) {
  int n = lines.size();
  int m = lines[0].size();

  // TODO:add solution here
  return 42;
}
