#include <string>
#include <vector>

int solve(std::vector<std::string> lines);
