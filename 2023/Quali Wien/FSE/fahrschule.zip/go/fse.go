package main

func solve(s []string) int {
	// TODO:add solution here
	return 42
}
