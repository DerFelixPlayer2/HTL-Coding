package main

import "fmt"

func main() {
	var n,m int;
	fmt.Scanf("%d %d", &n,&m)
	var input = make([]string, n); 
	
	for i := 0; i < n; i++ {
		fmt.Scanln(&input[i]);
	}

	res := solve(input)
	fmt.Println(res)
}
