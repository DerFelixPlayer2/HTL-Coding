export function solve(field) {
    const n = field.length;
    const m = field[0].length;
    // TODO: add solution here
    return 42;
}
