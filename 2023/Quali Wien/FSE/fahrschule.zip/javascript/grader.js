// DIESE DATEI NICHT BEARBEITEN
const readline = require('readline');
const fse = require('./fse');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

const getLine = (function () {
    const getLineGen = (async function* () {
        for await (const line of rl) {
            yield line;
        }
    })();
    return async () => ((await getLineGen.next()).value);
})();

const main = async () => {
    const line = await getLine();
    const parts = line.split(' ').map(x => parseInt(x));
    const n = parts[0];
    const m = parts[1];
    const field = [];
    for (let i = 0; i < n; i++) {
        const line = await getLine();
        field.push(line);
    }
    const result = fse.solve(field);
    console.log(result);

    rl.close();
    process.exit(0);
};

main();
