#pragma once

void hanoi(int);
void move(int,int);
void status();
