#include "hanoi.h"

void hanoi(int n)
{
	
}
